# FurniCraft - Website Company Profile Furniture (Inspirasi Warisan.com)

Website company profile untuk perusahaan furniture modern dan futuristik dengan desain elegan dan minimalis, terinspirasi dari warisan.com.

## 🌐 Live Demo
**URL Website:** https://pzhnbwji.manus.space

## 📋 Fitur Utama

### 3 Halaman Utama:
1. **About Us** (`index.html`) - Informasi perusahaan, sejarah, visi/misi, dan proses produksi
2. **Video** (`video.html`) - Halaman video produksi dengan placeholder YouTube embed
3. **Catalog** (`catalog.html`) - Galeri produk furniture dalam layout grid 3 kolom

## 🎨 Desain (Inspirasi Warisan.com)

### Karakteristik Desain Utama:
- **Full-width Hero Sections** dengan background images berkualitas tinggi
- **Rich Visual Content** dengan photography yang professional
- **Elegant Typography** menggunakan kombinasi serif dan sans-serif
- **Generous Whitespace** untuk kesan mewah dan clean
- **Premium Color Palette** yang sophisticated

### Warna Palette (Natural Futuristic)
- **Primary:** `#2F3C4F` (Dark Slate Blue) - Warna utama yang solid dan modern
- **Secondary:** `#A9B7C0` (Light Grayish Blue) - Background dan elemen sekunder
- **Accent:** `#D0D6E0` (Platinum) - Highlights dan accents
- **Supporting:** `#6B7A8F`, `#8E9CA7` - Variasi dan depth

### Typography
- **Headings:** Playfair Display (Serif) - Elegan dan mewah seperti warisan.com
- **Body Text:** Inter (Sans-serif) - Modern dan readable

### Layout Principles
- **Hero-driven Design** - Setiap halaman dimulai dengan hero section yang impactful
- **Card-based Content** - Informasi diorganisir dalam cards dengan shadow dan hover effects
- **Grid System** - Layout yang konsisten dan terstruktur
- **Visual Hierarchy** - Typography dan spacing yang jelas

## 🛠️ Teknologi

- **HTML5** - Struktur semantik dan accessible
- **Tailwind CSS** - Styling dan responsivitas dengan custom color palette
- **JavaScript** - Interaksi dasar (mobile menu, smooth scrolling, header effects)
- **Google Fonts** - Typography premium (Playfair Display + Inter)

## 📱 Responsivitas

Website telah dioptimasi untuk berbagai ukuran layar dengan pendekatan mobile-first:

### Desktop (1024px+)
- Grid 3 kolom untuk katalog produk
- Layout 2 kolom untuk About Us sections
- Navigation horizontal yang lengkap
- Hero sections dengan typography yang proporsional

### Tablet (768px - 1023px)
- Grid 2 kolom dengan spacing yang disesuaikan
- Navigation yang tetap accessible
- Images dan content yang optimal

### Mobile (375px - 767px)
- Grid 1-2 kolom tergantung konten
- Hamburger menu yang smooth
- Touch-friendly buttons dan links
- Typography yang readable di layar kecil

## 📁 Struktur File

```
furniture-website-warisan/
├── index.html              # Halaman About Us
├── video.html               # Halaman Video
├── catalog.html             # Halaman Catalog
├── assets/
│   └── images/             # Gambar berkualitas tinggi
│       ├── hero-about.jpg      # Hero background About Us
│       ├── hero-video.jpg      # Hero background Video
│       ├── hero-catalog.jpg    # Hero background Catalog
│       ├── production-bg.jpg   # Background production process
│       └── product-*.jpg       # Gambar produk (1-9)
├── wireframe.md            # Dokumentasi wireframe
├── testing_results.md      # Hasil testing lengkap
└── README.md              # Dokumentasi ini
```

## 🚀 Cara Menjalankan Lokal

1. Download semua file proyek
2. Buka `index.html` di browser web modern
3. Navigasi antar halaman menggunakan menu header
4. Test responsivitas dengan developer tools

## 🎯 Inspirasi dari Warisan.com

Website ini mengadopsi elemen-elemen kunci dari warisan.com:

### Visual Impact
- **Large Background Images** - Hero sections yang memukau
- **Professional Photography** - Gambar produk berkualitas tinggi
- **Rich Visual Content** - Emphasis pada visual storytelling

### User Experience
- **Intuitive Navigation** - Menu yang clear dan accessible
- **Smooth Interactions** - Hover effects dan transitions yang halus
- **Premium Feel** - Kesan mewah melalui design choices

### Layout & Typography
- **Generous Whitespace** - Breathing room yang cukup
- **Elegant Typography** - Kombinasi serif untuk headings
- **Card-based Design** - Content organization yang clean

## 📝 Catatan Pengembangan

- Website menggunakan CDN untuk Tailwind CSS dan Google Fonts
- Gambar produk sudah dioptimasi untuk web
- Video placeholder siap untuk diganti dengan YouTube embed yang sebenarnya
- Semua hover effects dan interactions sudah diimplementasi
- Color palette custom terintegrasi dengan Tailwind config

## 🎯 Target Audience

Website ini dirancang untuk:
- Klien premium yang mencari furniture berkualitas tinggi
- Interior designer dan arsitek profesional
- Perusahaan yang membutuhkan furniture kantor mewah
- Individu dengan taste untuk desain modern dan futuristik

## 🔧 Fitur Teknis

### Performance
- Optimized images untuk loading yang cepat
- CDN untuk CSS dan fonts
- Minimal JavaScript untuk performa optimal

### Accessibility
- Semantic HTML structure
- Proper alt texts untuk images
- Keyboard navigation support
- Color contrast yang memadai

### SEO Ready
- Proper meta tags
- Semantic markup
- Clean URL structure
- Image optimization

## 📞 Kontak

Untuk pertanyaan atau customization lebih lanjut, silakan hubungi tim development.

---

**© 2025 FurniCraft. All rights reserved.**

*Inspired by the elegant design principles of warisan.com*

