# Wireframe Website Furniture Company Profile (Inspirasi Warisan.com)

## Struktur Umum Website

### Header (Semua Halaman)
```
[LOGO: FurniCraft]                    [About] [Video] [Catalog] [Contact]
```
*Catatan: Header dengan background transparan di hero section, solid di scroll*

### Footer (Semua Halaman)
```
[Contact Info] | [Social Media Links] | [© 2025 FurniCraft]
```

---

## 1. Halaman About Us

### Layout Desktop:
```
+----------------------------------------------------------+
|  HEADER (Transparan)                                     |
+----------------------------------------------------------+
|                                                          |
|  [HERO SECTION - FULL SCREEN IMAGE BACKGROUND]          |
|  Tentang FurniCraft                                      |
|  Subtitle: Menciptakan furniture modern untuk masa depan |
|  [CTA Button: Lihat Koleksi]                            |
|                                                          |
+----------------------------------------------------------+
|                                                          |
|  [COMPANY INFO SECTION - 2 KOLOM]                       |
|  Kolom 1: Sejarah Singkat + Image                       |
|  Kolom 2: Visi & Misi + Image                           |
|                                                          |
+----------------------------------------------------------+
|                                                          |
|  [PRODUCTION PROCESS SECTION - BACKGROUND IMAGE]        |
|  Judul: Proses Produksi Kami                            |
|  [Card 1] [Card 2] [Card 3] [Card 4]                    |
|  Desain   Produksi  Quality  Finishing                  |
|  (Cards dengan background semi-transparan)              |
|                                                          |
+----------------------------------------------------------+
|                                                          |
|  [CALL TO ACTION SECTION]                                |
|  "Siap untuk furniture impian Anda?"                    |
|  [Button: Hubungi Kami] [Button: Lihat Katalog]        |
|                                                          |
+----------------------------------------------------------+
|  FOOTER                                                  |
+----------------------------------------------------------+
```

### Layout Mobile:
```
+------------------------+
|  HEADER                |
+------------------------+
|  [HERO SECTION]        |
|  Tentang FurniCraft    |
|  Subtitle              |
|  [CTA Button]          |
+------------------------+
|  [COMPANY INFO]        |
|  Sejarah Singkat       |
|  + Image               |
|  (Stack vertikal)      |
+------------------------+
|  Visi & Misi           |
|  + Image               |
+------------------------+
|  [PRODUCTION PROCESS]  |
|  Proses Produksi       |
|  [Card] Desain         |
|  [Card] Produksi       |
|  [Card] Quality        |
|  [Card] Finishing      |
+------------------------+
|  [CALL TO ACTION]      |
|  [Button: Hubungi]     |
|  [Button: Katalog]     |
+------------------------+
|  FOOTER                |
+------------------------+
```

---

## 2. Halaman Video

### Layout Desktop:
```
+----------------------------------------------------------+
|  HEADER (Transparan)                                     |
+----------------------------------------------------------+
|                                                          |
|  [HERO SECTION - BACKGROUND IMAGE]                      |
|  Video Produksi                                          |
|  Subtitle: Lihat proses pembuatan furniture kami        |
|                                                          |
+----------------------------------------------------------+
|                                                          |
|  [VIDEO SECTION - CENTERED]                             |
|  +------------------------------------------+           |
|  |                                          |           |
|  |        [YouTube Video Embed]             |           |
|  |        (16:9 Aspect Ratio)               |           |
|  |        dengan thumbnail menarik          |           |
|  |                                          |           |
|  +------------------------------------------+           |
|                                                          |
+----------------------------------------------------------+
|                                                          |
|  [DESCRIPTION SECTION - 2 KOLOM]                        |
|  Kolom 1: Deskripsi video                               |
|  Kolom 2: Fitur-fitur yang ditampilkan                  |
|                                                          |
+----------------------------------------------------------+
|                                                          |
|  [RELATED CONTENT SECTION]                              |
|  "Tertarik dengan produk kami?"                         |
|  [3 Featured Products dengan gambar]                    |
|                                                          |
+----------------------------------------------------------+
|  FOOTER                                                  |
+----------------------------------------------------------+
```

### Layout Mobile:
```
+------------------------+
|  HEADER                |
+------------------------+
|  [HERO SECTION]        |
|  Video Produksi        |
|  Subtitle              |
+------------------------+
|  [VIDEO SECTION]       |
|  +------------------+  |
|  |                  |  |
|  |  YouTube Video   |  |
|  |  (Responsive)    |  |
|  |                  |  |
|  +------------------+  |
+------------------------+
|  [DESCRIPTION]         |
|  Deskripsi video       |
|  (Stack vertikal)      |
+------------------------+
|  [FEATURES]            |
|  Fitur-fitur           |
+------------------------+
|  [RELATED PRODUCTS]    |
|  [Product 1]           |
|  [Product 2]           |
|  [Product 3]           |
+------------------------+
|  FOOTER                |
+------------------------+
```

---

## 3. Halaman Catalog

### Layout Desktop:
```
+----------------------------------------------------------+
|  HEADER (Transparan)                                     |
+----------------------------------------------------------+
|                                                          |
|  [HERO SECTION - BACKGROUND IMAGE]                      |
|  Katalog Produk                                          |
|  Subtitle: Koleksi furniture modern dan futuristik      |
|  [Search Bar] [Filter Dropdown]                         |
|                                                          |
+----------------------------------------------------------+
|                                                          |
|  [PRODUCT GRID - 3 KOLOM]                               |
|  +-------+  +-------+  +-------+                        |
|  | IMG 1 |  | IMG 2 |  | IMG 3 |                        |
|  | Name  |  | Name  |  | Name  |                        |
|  | Price |  | Price |  | Price |                        |
|  | [View]|  | [View]|  | [View]|                        |
|  +-------+  +-------+  +-------+                        |
|                                                          |
|  +-------+  +-------+  +-------+                        |
|  | IMG 4 |  | IMG 5 |  | IMG 6 |                        |
|  | Name  |  | Name  |  | Name  |                        |
|  | Price |  | Price |  | Price |                        |
|  | [View]|  | [View]|  | [View]|                        |
|  +-------+  +-------+  +-------+                        |
|                                                          |
|  +-------+  +-------+  +-------+                        |
|  | IMG 7 |  | IMG 8 |  | IMG 9 |                        |
|  | Name  |  | Name  |  | Name  |                        |
|  | Price |  | Price |  | Price |                        |
|  | [View]|  | [View]|  | [View]|                        |
|  +-------+  +-------+  +-------+                        |
|                                                          |
+----------------------------------------------------------+
|                                                          |
|  [CONSULTATION SECTION - BACKGROUND IMAGE]              |
|  "Butuh konsultasi furniture custom?"                   |
|  [Button: Hubungi Kami] [Button: Lihat Video]          |
|                                                          |
+----------------------------------------------------------+
|  FOOTER                                                  |
+----------------------------------------------------------+
```

### Layout Mobile:
```
+------------------------+
|  HEADER                |
+------------------------+
|  [HERO SECTION]        |
|  Katalog Produk        |
|  Subtitle              |
|  [Search] [Filter]     |
+------------------------+
|  [PRODUCT GRID - 1 COL]|
|  +------------------+  |
|  |      IMG 1       |  |
|  |      Name        |  |
|  |      Price       |  |
|  |     [View]       |  |
|  +------------------+  |
|  +------------------+  |
|  |      IMG 2       |  |
|  |      Name        |  |
|  |      Price       |  |
|  |     [View]       |  |
|  +------------------+  |
|  +------------------+  |
|  |      IMG 3       |  |
|  |      Name        |  |
|  |      Price       |  |
|  |     [View]       |  |
|  +------------------+  |
|  (dst...)              |
+------------------------+
|  [CONSULTATION]        |
|  [Button: Hubungi]     |
|  [Button: Video]       |
+------------------------+
|  FOOTER                |
+------------------------+
```

---

## Elemen Desain Utama (Inspirasi Warisan.com):

1. **Hero Sections dengan Background Images:**
   - Gambar berkualitas tinggi sebagai background
   - Overlay gelap untuk keterbacaan teks
   - Typography yang bold dan menarik

2. **Warna Palette:**
   - Primary: #2F3C4F (Dark Slate Blue)
   - Secondary: #A9B7C0 (Light Grayish Blue)
   - Accent: #D0D6E0 (Platinum)
   - Supporting: #6B7A8F, #8E9CA7

3. **Typography:**
   - Headings: Playfair Display (Serif)
   - Body: Inter (Sans-serif)

4. **Layout Principles:**
   - Full-width hero sections
   - Generous whitespace
   - Card-based content organization
   - Strong visual hierarchy

5. **Interaksi:**
   - Hover effects pada cards dan buttons
   - Smooth scrolling
   - Parallax effects (optional)
   - Responsive grid layout

6. **Call-to-Action:**
   - Prominent buttons di setiap section
   - Clear navigation path
   - Multiple contact points

